#include <WProgram.h>
#include "Morse.h"
�
Morse::Morse(int pin){
	pinMode(pin, OUTPUT);
	_pin=&pin;
}

�
void Morse::punto(){
	digitalWrite(_pin,HIGH);
	delay(250);
	digitalWrite(_pin,LOW);
	delay(250);
}
�
void Morse::linea(){
	digitalWrite(_pin,HIGH);
	delay(1000);
	digitalWrite(_pin,LOW);
	delay(250);
}
