var searchData=
[
  ['peek',['peek',['../class_wi_fly.html#a5d49f52b6340f5217460f135ce6de445',1,'WiFly']]],
  ['ping',['ping',['../class_wi_fly.html#a42af2ee53a70b6dc2c0292f80cde5d53',1,'WiFly']]]
];
