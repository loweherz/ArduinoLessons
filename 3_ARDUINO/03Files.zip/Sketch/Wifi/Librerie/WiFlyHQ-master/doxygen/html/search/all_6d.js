var searchData=
[
  ['match',['match',['../class_wi_fly.html#ac5e433e67b7412389784bcee0ed37a57',1,'WiFly::match(const char *str, uint16_t timeout=WIFLY_DEFAULT_TIMEOUT)'],['../class_wi_fly.html#a3d644dbb4d52d6beb75f325e5986b8de',1,'WiFly::match(const __FlashStringHelper *str, uint16_t timeout=WIFLY_DEFAULT_TIMEOUT)']]],
  ['multimatch_5fp',['multiMatch_P',['../class_wi_fly.html#a0bea886de94a92cafee3730d182f1914',1,'WiFly']]]
];
